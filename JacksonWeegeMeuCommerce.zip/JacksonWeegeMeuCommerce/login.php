<form method="post">
    Login: <br>
    <input type="text" name="login" placeholder="e-mail">
    <br>
    Senha:<br>
    <input type="password" name="senha">
    <br>
    <input type="submit" name="autenticar" value="Logar">
</form>